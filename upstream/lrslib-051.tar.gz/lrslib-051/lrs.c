#include <stdio.h>
#include <string.h>
#include "lrslib.h"
int 
main (int argc, char *argv[])

{
	  lrs_main(argc,argv);
	  printf("\n");
  	return 0;
}
